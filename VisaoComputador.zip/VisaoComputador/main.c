#include <stdio.h>
#include <stdlib.h>
#include "vc.h"

int main() {
	IVC* image;
	image = vc_read_image("Images/Blobs/labelling-2.pgm");
	IVC* destImage = vc_image_new(image->width, image->height, 1, 255);
	IVC* destImage2 = vc_image_new(image->width, image->height, 1, 255);

	int nlabels;
	OVC* blobs = vc_binary_blob_labelling(image, destImage, &nlabels);
	vc_binary_blob_info(destImage, blobs, nlabels);
	destImage2 = destImage;

	int xx = 495, y = 126;
	long int pos = y * destImage->bytesperline + xx;
	int dwada = destImage->data[pos];
	int p1 = blobs[1].x;
	int p5 = blobs[1].y;
	int p6 = blobs[0].height;
	int p2 = blobs[0].width;

	vc_write_image("labeling.pgm", destImage2);
}